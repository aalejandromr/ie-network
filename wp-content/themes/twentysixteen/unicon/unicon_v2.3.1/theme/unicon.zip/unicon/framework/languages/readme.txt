To translate or rename, copy and rename the en_EN.po file to xx_XX.po where 'xx' is your country code for the language, e.g. for french: fr_FR.po, for german: de_DE.po and so on.

Edit the po file with an editor like poEdit (http://www.poedit.net/) to do the desired translations and save the file. A new xx_XX.mo file should be generated. Make sure to place it in the same directory as the initial files. After your translation make sure that your WordPress Installation has the right language setting in your WordPress Admin Area under Settings > General > Site Language.

Enjoy!